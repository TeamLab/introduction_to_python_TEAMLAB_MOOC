# -*- coding: utf-8 -*-
def convert_celsius_fahrenheit(a):
    fahrenheit_value = float(((9/5)*a) + 32)
    return fahrenheit_value

def main():
    print("본 프로그램은 섭씨를 화씨로로 변환해주는 프로그램입니다")
    print("============================")
    # ===Modify codes below=================

    # ======================================
    print("===========================")
    print("프로그램이 종료 되었습니다.")


if __name__ == '__main__':
    main()
