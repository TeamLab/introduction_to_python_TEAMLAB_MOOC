#!/bin/bash
pip install backend.ai-client
