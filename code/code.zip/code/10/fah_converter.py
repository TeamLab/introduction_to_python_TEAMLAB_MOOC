#fah_converter.py
def covert_c_to_f(celsius_value):
    return celsius_value * 9.0 / 5 + 32

test_value = 0
