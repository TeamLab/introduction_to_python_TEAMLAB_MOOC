print("Enter your name")
somebody = input()
print("Hi", somebody)
