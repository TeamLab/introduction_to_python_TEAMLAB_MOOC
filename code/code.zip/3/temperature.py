temperature = float(input("온도를 입력하세요 :"))
print(temperature)
print(type(temperature))
