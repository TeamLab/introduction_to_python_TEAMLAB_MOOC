# echo.py
def echo_test():
    print ("echo")