from graphic.render import render_test
from sound.echo import echo_test

if __name__ == "__main__":
    render_test()
    echo_test()
