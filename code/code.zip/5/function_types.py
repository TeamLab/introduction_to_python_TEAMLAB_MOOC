# def a_calculateRectangleArea():
#     print (5 * 7)
# def b_calculateRectangleArea(x, y):
#     print (x * y)
# print(b_calculateRectangleArea(4, 8))
# def c_calculateRectangleArea():
#     return 5 * 7

def d_calculateRectangleArea(x, y):
    print("함수 안에 있습니다")
    return (x * y)
print(d_calculateRectangleArea(5,7))
