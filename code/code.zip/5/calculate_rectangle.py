def calculate_rectangle_area(x,y):
    return x*y

rectangle_x = 10
rectangle_y = 20
print(calculate_rectangle_area(
    rectangle_x, rectangle_y))
