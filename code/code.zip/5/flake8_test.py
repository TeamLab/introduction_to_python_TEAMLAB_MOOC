lL0O  =  "123"
for i in 10 :
    print ("Hello")