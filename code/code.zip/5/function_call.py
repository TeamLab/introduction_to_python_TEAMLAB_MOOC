def test(t):
    print(t)
    t = 20
    print ("In Function :", t)

x = 10
print ("Before :", x)
test(x)
print ("After :", x)
