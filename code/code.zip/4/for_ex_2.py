for i in range(10, 1, -2):
    print(i)
