print("Tell me your age?")
myage = int(input())
if (myage < 30):
    print("Welcome to the Club")
else:
    print("Oh! No. You are not accepted")
