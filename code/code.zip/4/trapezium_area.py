def addtition(x,y):
    return x+y

if __name__ == "__main__":
    print(addtition(10,5))
